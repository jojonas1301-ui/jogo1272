@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
 echo Instale Node.js 20 ou superior e tente novamente.
 pause
 exit /b 1
)
call npm ci --omit=dev
if errorlevel 1 (
 pause
 exit /b 1
)
echo Abra http://localhost:3000 no navegador.
echo Mantenha esta janela aberta enquanto joga.
call npm start
pause
